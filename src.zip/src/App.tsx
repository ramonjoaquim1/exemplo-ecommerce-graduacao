import "./style.css";
import logoSenac from "./pic/logo.png"
import MenuBar from "./components/MenuBar";
import Router from "./Router";

function App() {
  return (
   <div className="body">
      <div className="corpo">
          <header>
            <div className="logo">
              < img src={logoSenac} alt="logo" />
            </div>
            <MenuBar /> 
          </header>
      <Router />
      </div>
   </div>
  );
}

export default App;
