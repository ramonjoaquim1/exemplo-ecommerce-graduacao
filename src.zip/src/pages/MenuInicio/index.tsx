import { FC } from "react";


const MenuInicio : FC = () => {
    return <>
        <div>Menu - Inicio - Teste</div>
    </>
}
export default MenuInicio;