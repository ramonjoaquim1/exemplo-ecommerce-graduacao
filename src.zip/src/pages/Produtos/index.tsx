import { FC } from "react";

const Produtos : FC = () => {
    return <>
        <div>Protutos-Teste</div>
    </>
}
export default Produtos;