import { FC, useEffect } from "react";
import { STATU_CODE, apiGet } from "../../api/RestClient";

const Home : FC = () =>{
    const carregaProdutos = async() => {
        const response = await apiGet("/produtos/");
        if (response.status === STATU_CODE.OK) {
            console.log(response);
        }
    }

    useEffect(() => {
        carregaProdutos();
    }, []);
    return <>
        <div>Home-Teste</div>
    </>
}
export default Home;