import { FC } from "react";

const Sobre : FC = () => {
    return <>
        <div>Sobre -Teste</div>
    </>
}
export default Sobre;